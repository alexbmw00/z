#!/bin/bash
clear
echo "ZABBIX AGENT INSTALL"
echo "ALEX CLEMENTE"
echo "Zabbix Agent - Version 3.2.4"

if [ $(arch | grep 32) ];then
   echo
   echo "ARCH i386"

groupadd zabbix
useradd -g zabbix zabbix -c "User ZABBIX" -M -s /bin/false

mkdir /var/log/zabbix
chown zabbix:zabbix /var/log/zabbix

cp zabbix-i386/bin/zabbix* /usr/local/bin/ && cp zabbix-i386/sbin/zabbix* /usr/local/sbin/
cp zabbix-i386/conf/zabbix_agentd.conf /usr/local/etc/
chown zabbix:zabbix /usr/local/bin/zabbix* /usr/local/sbin/zabbix*
chmod 550 /usr/local/bin/zabbix* /usr/local/sbin/zabbix*

echo
echo "PLEASE IP ZABBIX:"
read ip

sed -i s/127.0.0.1/$ip/g /usr/local/etc/zabbix_agentd.conf
sed -i s/Hostname=localhost/Hostname=$(uname -n)/g /usr/local/etc/zabbix_agentd.conf
/usr/local/sbin/zabbix_agentd -c /usr/local/etc/zabbix_agentd.conf

echo
echo "STATUS ZABBIX:" $(ps aux | grep -v grep | grep zabbix | awk '{print $2}')

echo
echo "INSTALL SUCCESS"

else
echo "ARCH x86_64"

groupadd zabbix
useradd -g zabbix zabbix -c "Usuario ZABBIX" -M -s /bin/false

mkdir /var/log/zabbix
chown zabbix:zabbix /var/log/zabbix

cp zabbix-x86_64/bin/zabbix* /usr/local/bin/ && cp zabbix-x86_64/sbin/zabbix* /usr/local/sbin/
cp zabbix-x86_64/conf/zabbix_agentd.conf /usr/local/etc/
chown zabbix:zabbix /usr/local/bin/zabbix* /usr/local/sbin/zabbix*
chmod 550 /usr/local/sbin/zabbix* /usr/local/sbin/zabbix*

echo
echo "PLEASE IP ZABBIX:"
read ip

sed -i s/127.0.0.1/$ip/g /usr/local/etc/zabbix_agentd.conf
sed -i s/Hostname=localhost/Hostname=$(uname -n)/g /usr/local/etc/zabbix_agentd.conf
/usr/local/sbin/zabbix_agentd -c /usr/local/etc/zabbix_agentd.conf

echo
echo "ZABBIX STATUS:" $(ps aux | grep -v grep | grep zabbix | awk '{print $2}')

fi

if [ -e /etc/redhat-release ];then
   echo "LINUX RED HAT"
   echo "WAIT..."

cp zabbix_agentd /etc/init.d/ && chmod 550 /etc/init.d/zabbix_agentd && /etc/init.d/zabbix_agentd restart >/dev/null 2>&1
chkconfig --level 35 zabbix_agentd on >/dev/null 2>&1

else
   echo "LINUX DEBIAN"
   echo "WAIT..."

cp zabbix-agent /etc/init.d/ && chmod 550 /etc/init.d/zabbix-agent && /etc/init.d/zabbix-agent restart >/dev/null 2>&1
update-rc.d -f zabbix-agent defaults >/dev/null 2>&1
fi

echo
echo "INSTALL SUCCESS"
echo

exit 0
